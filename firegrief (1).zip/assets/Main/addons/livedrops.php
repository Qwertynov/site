<?php
include "config.php";
$link = mysqli_connect($config['db']['host'], $config['db']['user'], $config['db']['password'], $config['db']['db']) or die('Ошибка подключения к БД, обновите страницу.');

$sql = mysqli_query($link, "SELECT * FROM live ORDER BY live_id DESC LIMIT 8");
while ($row = mysqli_fetch_array($sql)) {
    $live_id = $row['live_id'];
    $live_name = $row['live_name'];
    $live_price = $row['live_price'];
    $live_img = $row['live_img'];
    $live_nickname = $row['live_nickname'];
    echo '<div class="drop-id"><div class="image" style="background-image: url('.$live_img.');"></div>
  <div class="price">'.$live_price.' <i class="fa fa-ruble" aria-hidden="true"></i></div><div class="drop-borders"><div></div>
  <div></div><div></div><div></div></div><div class="tooltip"><p><b>Игрок</b>: '.$live_nickname.'</p><p><b>Купил</b>: '.$live_name.'</p></div></div>';
}
?>