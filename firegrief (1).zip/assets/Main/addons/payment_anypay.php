<?php
define("TKM", true);
require_once('./functions.php');
require_once('./config.php');
require_once('./rcon.class.php');

$anypay_ips = [
    '213.174.29.83',
    '185.162.128.38',
    '185.162.128.39',
    '185.162.128.88',
    '127.0.0.1',
];

function getrIP() {
	if (isset($_SERVER['HTTP_X_REAL_IP'])) {
		return $_SERVER['HTTP_X_REAL_IP'];
	}

	return $_SERVER['REMOTE_ADDR'];
}

function giveDonate($config, $rLength = 0) {
    if ($rLength == 10) {
        echo "RCON ERROR\n";
        return;
    }
	
	$good_price = $_REQUEST['amount'];
	$nickname = $_REQUEST['field1'];
	$goods = $_REQUEST['field2'];
    $amount = $_REQUEST['field3'];
    $currentGood = findGood($config, $goods);
	$payid = $_REQUEST['pay_id'];
    $cmd = str_replace(['%user%', '%group%', '%amount%'], [$nickname, $goods, $amount], $currentGood['command']);
	//$cmd1 = "lp user ".$nickname." parent set ".$donate;
    $rcon = new Rcon($config['rcon']['ip'], $config['rcon']['port'], $config['rcon']['password'], 10);
    
	$db = mysqli_connect($config['db']['host'], $config['db']['user'], $config['db']['password'], $config['db']['db']) or die('Ошибка подключения к БД, обновите страницу.');

	$stmts = $db->prepare("INSERT INTO live (live_id, live_nickname, live_name, live_price, live_img) VALUES (?, ?, ?, ?, ?)");
	$stmts->bind_param('issss',  $payid, $nickname, $goods, $good_price, $currentGood['image']);
	$stmts->execute();
	
    if ($rcon->connect()) {
	echo "COMMAND " . $cmd . "\n";
        $rcon->send_command($cmd);
    } else {
        echo "RCON TRY NEXT\n";
        giveDonate($config, $rLength + 1);
    }
}

if (!in_array($_SERVER['REMOTE_ADDR'], $anypay_ips)) {
    die('Ошибка доступа');
}

$sign = md5($config['anypay']['site_id'].':'.$_REQUEST['amount'].':'.$_REQUEST['pay_id'].':'.$config['anypay']['secret_key']);

if ($sign != $_REQUEST['sign']) {
	exit("ERROR_bad sign");
}

    //switch($_REQUEST['method']) {
       // case 'pay':
            giveDonate($config);
           // break;
       // default:
            //sendUnitResponse('Параметры верны. Платёж разрешён', 'result');
           // break;
    //}

exit("OK");
