<?php

$config = [
    "site_name" => "FireGrief",
    "description" => "Официальный сайт сервера в Minecraft - FireGrief. Здесь вы сможете найти всю нужную информацию для начала игры на сервере, а также получать последние новости о нас и о мире Minecraft в целом.", // Описание
    "keywords" => "FIREGRIEF, FIREGRIEF.RU, tlauncher, гриферский сервер, сервер, сервер майнкрафт, сайт FireGrief, купить донат", // Ключевые слова для поисковиков
    "server_ip" => "hypixel.net", // IP сервера
	"vk_group" => "",
    "vk_support" => "",
    "email" => "",
    "db" => [
        "host" => "127.0.0.1",
        "user" => "root",
        "password" => "",
        "db" => "test",
    ],
    "enot" => [
        "public_key" => "",
        "secret_key" => "",
    ],
    "anypay" => [
        "project_id" => "9263",
        "key" => "RvjCR75NotCqHYZQnTIu6SP163zSULVaKTOs6V7",
    ],
    "rcon" => [
        "ip" => "",
        "port" => "",
        "password" => ""
    ],
    "promo" => [
        "TABLETO4KA" => 20,
	],
    "categories" => [
        "category" => [
            "title" => "Привилегии",
            "default" => true,
            "icon" => "/assets/Main/img/1.png",
            "products" => [
                "lite" => [
                    "title" => "HERO",
                    "text" => "Навсегда",
                    "price" => 10.00,
                    "image" => "/assets/Main/img/donate/hero.webp",
                    "command" => "lp user %user% parent set %group%",
                    "promo_use" => true,
                ],
                "voin" => [
                    "title" => "FERK",
                    "text" => "Навсегда",
                    "price" => 20.00,
                    "image" => "/assets/Main/img/donate/ferk.webp",
                    "command" => "lp user %user% parent set %group%",
                    "promo_use" => true,
                ],
		"phantom" => [
                    "title" => "LIME",
                    "text" => "Навсегда",
                    "price" => 55.00,
                    "image" => "/assets/Main/img/donate/lime.webp",
                    "command" => "lp user %user% parent set %group%",
                    "promo_use" => true,
                ],
		"imperator" => [
                    "title" => "MINER",
                    "text" => "Навсегда",
                    "price" => 75.00,
                    "image" => "/assets/Main/img/donate/miner.webp",
                    "command" => "lp user %user% parent set %group%",
                    "promo_use" => true,
                ],
		"wither" => [
                    "title" => "FIRE",
                    "text" => "Навсегда",
                    "price" => 139.00,
                    "image" => "/assets/Main/img/donate/fire.webp",
                    "command" => "lp user %user% parent set %group%",
                    "promo_use" => true,
                ],
		"korol" => [
                    "title" => "GUARDIAN",
                    "text" => "Навсегда",
                    "price" => 249.00,
                    "image" => "/assets/Main/img/donate/guardian.webp",
                    "command" => "lp user %user% parent set %group%",
                    "promo_use" => true,
                ],
		"legend" => [
                    "title" => "MERCHANT",
                    "text" => "Навсегда",
                    "price" => 349.00,
                    "image" => "/assets/Main/img/donate/merchant.webp",
                    "command" => "lp user %user% parent set %group%",
                    "promo_use" => true,
                ],
		"guner" => [
                    "title" => "WELF",
                    "text" => "Навсегда",
                    "price" => 500.00,
                    "image" => "/assets/Main/img/donate/welf.webp",
                    "command" => "lp user %user% parent set %group%",
                    "promo_use" => true,
                ]

            ]
        ],
		"category2" => [
            "title" => "Рубли",
            "icon" => "/Themes/Main/img/3.png",
            "products" => [
                "rub1" => [
                    "title" => "250P",
                    "text" => "Пополняй и закупайся",
                    "price" => 50.00,
                    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 250",
                    "promo_use" => true,
                ],
		"rub2" => [
		    "title" => "500P",
                    "text" => "Пополняй и закупайся",
		    "price" => 55.00,
		    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 500",
                    "promo_use" => true,
                ],
                "rub3" => [
                    "title" => "750P",
                    "text" => "Пополняй и закупайся",
                    "price" => 70.00,
                    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 750",
                    "promo_use" => true,
                ],
                "rub4" => [
                    "title" => "1000P",
                    "text" => "Пополняй и закупайся",
                    "price" => 90.00,
                    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 1000",
                    "promo_use" => true,
                ],
                "rub5" => [
                    "title" => "1500P",
                    "text" => "Пополняй и закупайся",
                    "price" => 125.00,
                    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 1500",
                    "promo_use" => true,
                ],
                "rub6" => [
                    "title" => "2000P",
                    "text" => "Пополняй и закупайся",
                    "price" => 150.00,
                    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 2000",
                    "promo_use" => true,
                ],
                "rub7" => [
                    "title" => "5000P",
                    "text" => "Пополняй и закупайся",
                    "price" => 200.00,
                    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 5000",
                    "promo_use" => true,
                ],
                "rub8" => [
                    "title" => "6000P + ГУНЕР",
                    "text" => "Пополняй и закупайся",
                    "price" => 400.00,
                    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 6000",
                    "promo_use" => true,
                ],
                "rub9" => [
                    "title" => "15000Р + СПОНСОР",
                    "text" => "Пополняй и закупайся",
                    "price" => 700.00,
                    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 15000",
                    "promo_use" => true,
                ],
                "rub10" => [
                    "title" => "50000P + СПОНСОР",
                    "text" => "Пополняй и закупайся",
                    "price" => 1000.00,
                    "image" => "/assets/Main/img/rub/3.png",
                    "command" => "p give %user% 50000",
                    "promo_use" => true,
                ],
            ]
		],
        "category3" => [
            "title" => "Кейсы",
            "icon" => "/assets/Main/img/4.png",
            "products" => [
                "donatecase1" => [
                    "title" => "Донат Кейс",
                    "text" => "1 шт.",
                    "price" => 59.00,
                    "image" => "/assets/Main/img/case/dc.webp",
                    "command" => "cases give %user% donat %amount%",
                    "promo_use" => true,
                ],
                "donatecase3" => [
                    "title" => "Донат Кейс",
                    "text" => "3 шт.",
                    "price" => 149.00,
                    "image" => "/assets/Main/img/case/dc.webp",
                    "command" => "cases give %user% donat %amount%",
                    "promo_use" => true,
                ],
                "donatecase10" => [
                    "title" => "Донат Кейс",
                    "text" => "10 шт.",
                    "price" => 499.00,
                    "image" => "/assets/Main/img/case/dc.webp",
                    "command" => "cases give %user% donat %amount%",
                    "promo_use" => true,
                ],
                "donatecase20" => [
                    "title" => "Донат Кейс",
                    "text" => "25 шт.",
                    "price" => 1249.00,
                    "image" => "/assets/Main/img/case/dc.webp",
                    "command" => "cases give %user% donat %amount%",
                    "promo_use" => true,
                ],
                "rubcase1" => [
                    "title" => "Кейс с рублями",
                    "text" => "1 шт.",
                    "price" => 59.00,
                    "image" => "/assets/Main/img/case/cc.webp",
                    "command" => "cases give %user% prefix %amount%",
                    "promo_use" => true,
                ],
                "rubcase3" => [
                    "title" => "Кейс с рублями",
                    "text" => "3 шт.",
                    "price" => 149.00,
                    "image" => "/assets/Main/img/case/cc.webp",
                    "command" => "cases give %user% prefix %amount%",
                    "promo_use" => true,
                ],
                "rubcase10" => [
                    "title" => "Кейс с рублями",
                    "text" => "10 шт.",
                    "price" => 499.00,
                    "image" => "/assets/Main/img/case/cc.webp",
                    "command" => "cases give %user% prefix %amount%",
                    "promo_use" => true,
                ],
                "rubcase25" => [
                    "title" => "Кейс с рублями",
                    "text" => "25 шт.",
                    "price" => 1299.00,
                    "image" => "/assets/Main/img/case/cc.webp",
                    "command" => "cases give %user% virt %amount%",
                    "promo_use" => true,
                ]

            ]
        ],
		"category4" => [
            "title" => "Прочее",
            "icon" => "/assets/Main/img/2.png",
            "products" => [
                "unban" => [
		    "title" => "Разбан",
                    "text" => "Разбан на сервере",
                    "price" => 49.00,
	            "image" => "/assets/Main/img/product/22.png",
                    "command" => "unban %user%",
                    "promo_use" => true,
                ],
                "razmut" => [
		    "title" => "Размут",
                    "text" => "Размутят на сервере",
                    "price" => 19.00,
	            "image" => "/assets/Main/img/product/23.png",
                    "command" => "unmute %user%",
                    "promo_use" => true,
                ],
                "bp" => [
                    "title" => "Батл Пасс",
                    "text" => "Выполняй прем задания",
                    "price" => 19.00,
                    "image" => "/assets/Main/img/product/50.png",
                    "command" => "bpa set pass premium %user%",
                    "promo_use" => true,
                ],
                "unicworld" => [
                    "title" => "Доступ в уник. мир",
                    "text" => "Доступ в уник. мир",
                    "price" => 149.00,
                    "image" => "/assets/Main/img/product/world.webp",
                    "command" => "bpa set pass premium %user%",
                    "promo_use" => true,
                ]
            ]
		]
    ]
];
