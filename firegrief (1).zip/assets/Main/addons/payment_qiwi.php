<?php
require_once('./functions.php');
require_once('./config.php');
require_once('./rcon.class.php');

//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') !== 0){
    echo '<script type="text/javascript">window.location.href="/";</script>';
    die();
}

//Receive the RAW post data.
$content = trim(file_get_contents("php://input"));

//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);

//If json_decode failed, the JSON is invalid.
if(!is_array($decoded)){
    die();
}

if($decoded['bill']['siteId'] !== $config['qiwi']['site_id']) die();
if($decoded['bill']['status']['value'] !== 'PAID') die();


function giveDonate($config, $goodParams, $rLength = 0) {
    if ($rLength == 10) {
        return;
    }

    $currentGood = findGood($config, $goodParams[1]);
    $cmd = str_replace(['%user%', '%group%', '%amount%'], [$goodParams[0], $goodParams[1], isset($goodParams[2]) ? $goodParams[2] : 0], $currentGood['command']);
    $rcon = new Rcon($config['rcon']['ip'], $config['rcon']['port'], $config['rcon']['password'], 10);

    if (@$rcon->connect()) {
        @$rcon->send_command($cmd);
    } else {
        giveDonate($config, $goodParams, $rLength + 1);
    }
}

$goodParams = explode('-', $decoded['bill']['customer']['account']);

if (count($goodParams) < 3)
    sendUnitResponse('Неправильный аккаунт');

$currentGood = findGood($config, $goodParams[1]);

if ($currentGood == null)
    sendUnitResponse('Привилегия отсутствует');

if (isset($currentGood['amount']) && $currentGood['amount'] && !isset($goodParams[3]))
    sendUnitResponse('Неправильное количество');

$price = calculatePrice($goodParams[0], $currentGood, isset($goodParams[3]) ? $goodParams[3] : 0, $goodParams[2], $config);

if ($price != $decoded['bill']['amount']['value'])
    sendUnitResponse('Неверная цена!');

$db = mysqli_connect($config['db']['host'], $config['db']['user'], $config['db']['password'], $config['db']['db']) or die('Ошибка подключения к БД, обновите страницу.');

$stmt = $db->prepare("INSERT INTO `live` (`live_nickname`, `live_name`, `live_price`, `live_img`) VALUES (?, ?, ?, ?)");
$stmt->bind_param('sssss',  $goodParams[0], $currentGood['title'], $currentGood['price'], $currentGood['image']);
$stmt->execute();

giveDonate($config, $goodParams);
