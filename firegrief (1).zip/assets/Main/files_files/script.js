
const csrf = document.querySelector('meta[name="csrf"]').content;
var app = {
    monitor_timeout: 10000,
    livedrops_timeout: 10000,

    loader: function(){

        axios.post('/api/modes', `_csrf=${csrf}`).then(function(e){
            const data = JSON.parse(JSON.stringify(e.data));

            $.each( data, function( key, row ) {
                const active = (key == "donate") ? "active" : "";

                $('.tab-links').append(`
                    <li data-id="${key}" class="${active}"><a href="#">${row}</a>
                        <ul>
                            <li class="active" name="${key}" style="display:none;"></li>
                        </ul>
                    </li>
                `);
            });


            $.each( data, function( key, row ) {
                const active = (key == "donate") ? "active" : "";

                $('.tab-list').append(`
                    <div class="tab-id ${active}" data-id="${key}">
                        <div class="items">
                            <div class="category ${key} active">

                            </div>
                        </div>
                    </div>
                `);
            });
        
            axios.post('/api/groups', `_csrf=${csrf}`).then(function(e){
        
                const data = JSON.parse(JSON.stringify(e.data));
    
                $.each( data, function( key, row ) {

                    if(key == "credits"){
						$(`.category.${row.mode}.active`).append(`
								<div data-modal="paymodal" class="item-id" data-item="${key}" data-server="${row.mode}">
									<div class="title">${row.name}</div>
									<div class="text">Пополняй и получай бонусы!</div>
									<div class="image" style="background-image: url('${row.img}');"></div>
									<div class="price">Пополнить</div>
								</div>
						`);
						return;
                    }
				   
                    $(`.category.${row.mode}.active`).append(`
                            <div data-modal="paymodal" class="item-id" data-item="${key}" data-server="${row.mode}">
                                <div class="title">${row.name}</div>
                                <div class="text">Навсегда</div>
                                <div class="image" style="background-image: url('${row.img}');"></div>
                                <div class="price">${row.price}₽</div>
                            </div>
                    `);
                })
            
            })

        });


    },

    monitor: function() {
        $.ajax({
            url: `https://api.mcsrvstat.us/2/${document.getElementById('ip').textContent}`,
            dataType: "json",
            type: "GET",
            async: true,
            cache: false,
            contentType: false,
            processData: false,
            data: {},
            error: function(data, textStatus, xhr) {
                if (typeof error != "undefined") {
                    error(data, textStatus, xhr);
                } else {
                    console.log(data);
                }
                $("#online, #slots").html("0");
                $("#progress").width("0");
                setTimeout(function() {
                    app.monitor();
                }, app.monitor_timeout);
            },
            success: function(data) {
                let online = !data.players.online ? 0 : data.players.online;
                let slots = !data.players.max ? 0 : data.players.max;
                $("#online").html(online);
                $("#slots").html(slots);
                let progress = !slots ? 0 : online / (slots / 100);
                $("#progress").width(progress.toFixed(4) + "%");
                setTimeout(function() {
                    app.monitor();
                }, app.monitor_timeout);
            },
        });
    },
    livedrops: function() {

        axios.post('/api/last', `_csrf=${csrf}`).then(function(resp){
            const data = JSON.parse(JSON.stringify(resp.data));

            let latestPurchases = "";
            $.each(data, function(index, b) {
                let item = '<div class="drop-id">';
                item += '<div class="image" style="background-image: url(' +
                    b.img +
                    ');"></div>';
                item += '<div class="price">' +
                    b.price +
                    ' <i class="fa fa-ruble"></i></div>';
                item += '<div class="drop-borders"><div></div><div></div><div></div><div></div></div>';
                item += '<div class="tooltip">';
                item += "<p><b>Игрок</b>: " + b.nick + "</p>";
                item += "<p><b>Купил</b>: " + b.name + "</p>";
                item += "</div>";
                item += "</div>";
                latestPurchases += item;
            });
            $(".livedrops .drops").html(latestPurchases);
            setTimeout(function() {
                app.livedrops();
            }, app.livedrops_timeout); 

        });

    },
};

$(function() {
    setTimeout(function() {
        app.monitor();
        app.livedrops();
    }, 100);
    $("body").on("click", ".copy-clipboard", function(e) {
        e.preventDefault();
        let that = $(this);
        that.html("COPIED!");
        setTimeout(function() {
            that.html(that.attr("data-clipboard-text"));
        }, 1000);
    }).on("click", ".tabs .tab-links > li > a", function(e) {
        e.preventDefault();
        let that = $(this);
        let li = that.closest("li");
        if (li.hasClass("active")) {
            return;
        }
        $(".tabs .tab-links > li").removeClass("active");
        li.addClass("active");
        let id = li.attr("data-id");
        let tabs = that.closest(".tabs");
        tabs.find(".tab-list > .tab-id.active > .items > .category.active").removeClass("active");
        tabs.find(".tab-links > li > ul > li.active").removeClass("active");
        tabs.find(".tab-list > .tab-id.active").removeClass("active");
        tabs.find('.tab-list > .tab-id[data-id="' + id + '"]').addClass("active");
        tabs.find(".tab-links > li.active > ul > li:first").addClass("active");
        tabs.find(".tab-list > .tab-id.active > .items > .category:first").addClass("active");
    }).on("click", "[data-modal]", function(e) {
        if (e.target.tagName != "INPUT") {
            e.preventDefault();
        }
        let that = $(this);
        let id = that.attr("data-modal");
        let modal = $('.modal[data-id="' + id + '"]');
        if (modal.length) {
            if (id == "paymodal") {

                if(that.attr("data-item") == "credits"){
                    console.log('оформляем вам кредит');
                    document.getElementById('count').style = ``;
                    document.getElementById('credits').type = 'text';
                } else {
                    document.getElementById('count').style = `display: none;`;
                    document.getElementById('credits').type = 'hidden';
                }

                
                modal.find(".modal-header").html(that.children(".title").html());
                modal.find('[type="submit"]').html("Оплатить");
                modal.find('[type="submit"]').prop( "enabled", true );
                modal.find('[name="group"]').val(that.attr("data-item"));
                modal.find('[name="server"]').val(that.attr("data-server"));
                modal.find('[name="price"]').val(that.attr("price"));
                modal.find('[name="title"]').val(that.attr("title"));
            }
            modal.fadeIn("fast", function() {
                $(this).addClass("active");
            });
        }
    }).on("click", ".modal [data-modal-close]", function(e) {
        e.preventDefault();
        $(".modal").fadeOut("fast", function() {
            $(this).removeClass("active");
        });
    }).on("click", ".modal", function(e) {
        let target = $(e.target);
        if (!target.closest(".modal-content").length) {
            $(".modal").fadeOut("fast", function() {
                $(this).removeClass("active");
            });
        }
    }).on("click", ".header .navbar .navbar-mobile", function(e) {
        e.preventDefault();
        $(this).closest(".navbar").toggleClass("active");
    }).on("click", ".spoiler-trigger", function(e) {
        e.preventDefault();
        let that = $(this);
        let element = $(".spoiler" + that.attr("data-id"));
        if (!element.length) {
            return;
        }
        element.slideToggle("fast", function() {
            $(this).toggleClass("active");
            that.toggleClass("active");
        });
    }).on("click", ".tabs .tab-links > li > ul > li", function(e) {
        e.preventDefault();
        let it = $(".tabs .tab-links > li > ul > li.active");
        let that = $(this);
        if (that.hasClass("active")) {
            return;
        }
        $(".tab-list > .tab-id.active > .items > .category." + it.attr("name")).removeClass("active");
        $(".tab-list > .tab-id.active > .items > .category." + that.attr("name")).addClass("active");
        it.removeClass("active");
        that.addClass("active");
    }).on("input", "#playername", function(){
        var nick = $("#playername").val();
        var credits = $("#credits").val();
        var group = $("#group").val();
        var promo = $("#promo").val();

        if(group == "credits"){
            if(!credits){
                $("button[type=submit]").text(`укажите кол-во кредитов`);
                $("button[type=submit]").prop('disabled', true);  
                return;
            }

            var group = `credits-${credits}`;
        }

        if($("#group").val().split('-')[0] == "credits"){
            var group = `credits-${credits}`;
        }

        axios.post('/api/status', `_csrf=${csrf}&nick=${nick}&group=${group}&promo=${promo}`).then(function(e){
            const data = JSON.parse(JSON.stringify(e.data));

            switch(data.status){

                case 'ok':
                    if($("#group").val() == "credits" || $("#group").val().split('-')[0] == "credits"){
                        document.getElementById('group').value = group;
                        $("button[type=submit]").text(`К оплате: ${data.price}₽ | Получите: ${data.count}㉿`);
                    } else {
                        $("button[type=submit]").text(`Оплатить ${data.price}₽`);
                    }
                    $("button[type=submit]").prop('disabled', false);
                break;

                case 'error':
                    $("button[type=submit]").text(data.message);
                    $("button[type=submit]").prop('disabled', true);
                break;

            }

        });
    }).on("input", "#credits", function(){

        var nick = $("#playername").val();
        var credits = $("#credits").val();
        var group = $("#group").val();
        var promo = $("#promo").val();
        if(!credits){
            $("button[type=submit]").text(`укажите кол-во кредитов`);
            $("button[type=submit]").prop('disabled', true);  
            return;
        }

        if(group == "credits"){
            var group = `${group}-${credits}`;
        }


        if($("#group").val().split('-')[0] == "credits"){
            var group = `credits-${credits}`;
        }

            axios.post('/api/status.php', `_csrf=${csrf}&nick=${nick}&group=${group}&promo=${promo}`).then(function(e){
                const data = JSON.parse(JSON.stringify(e.data));

                switch(data.status){

                    case 'ok':
                        if($("#group").val() == "credits" || $("#group").val().split('-')[0] == "credits"){
                            document.getElementById('group').value = group;
                            $("button[type=submit]").text(`К оплате: ${data.price}₽ | Получите: ${data.count}㉿`);
                        } else {
                            $("button[type=submit]").text(`Оплатить ${data.price}₽`);
                        }
                        $("button[type=submit]").prop('disabled', false);
                    break;

                    case 'error':
                        $("button[type=submit]").text(data.message);
                        $("button[type=submit]").prop('disabled', true);
                    break;

                }
            })

    })

    new ClipboardJS(".copy-clipboard");
});
