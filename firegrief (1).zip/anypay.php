<?php
@session_start();
require_once('../assets/Main/addons/functions.php');
require_once('../assets/Main/addons/config.php');

$link = mysqli_connect($config['db']['host'], $config['db']['user'], $config['db']['password'], $config['db']['db']) or die('Ошибка подключения к БД, обновите страницу.');
$sql = mysqli_query($link, "SELECT * FROM live ORDER BY live_id");
while ($row = mysqli_fetch_array($sql)) {
    $live_id = $row['live_id'];
}
	
$payid = $live_id + "1";
$payNum = $currentGood['amount'] ? "{$_GET['login']}-{$_GET['good']}-{$promo}-{$_GET['amount']}" : "{$_GET['login']}-{$_GET['good']}-{$promo}";
$desc = "Покупка игровой привилегии на сайте {$config['site_name']}";
$signature = md5($config['anypay']['currency'].':'.$price.':'.$config['anypay']['secret_key'].':'.$config['anypay']['site_id'].':'.$payid); 

header( "Location: https://anypay.io/merchant?merchant_id={$config['anypay']['site_id']}&currency={$config['anypay']['currency']}&amount={$price}&pay_id={$payid}&desc={$desc}&sign={$signature}&field1={$_GET['login']}&field2={$_GET['good']}&field3={$_GET['amount']}");