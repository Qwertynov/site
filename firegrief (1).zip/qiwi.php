<?php
@session_start();
require_once('./assets/Main/addons/functions.php');
require_once('./assets/Main/addons/config.php');

$price = $_GET['price'];
$payNum = $currentGood['amount'] ? "{$_GET['nick']}-{$_GET['good']}-{$promo}-{$_GET['price']}" : "{$_GET['nick']}-{$_GET['good']}-{$promo}";
$desc = "Покупка игровой привилегии на сайте {$config['site_name']}";
$signature = hash('SHA256', $payNum.'{up}'.$desc.'{up}'.$price.'{up}'.$config['unitpay']['key']);

header( "Location: https://oplata.qiwi.com/create?publicKey={$config['qiwi']['public_key']}&amount={$price}&account={$payNum}&comment={$desc}&successUrl=https://welfsine.ru/");