<!DOCTYPE html>
<?php
require('assets/Main/addons/config.php')
?>
<!-- saved from url=(0026)https://xworld.su/pay/4774 -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title><?=$config['site_name']?> — Оплата счета</title>

    

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" href="<?=$config['site']?>favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="./assets/Main/oplata_files/quick-website.css">

    <link rel="stylesheet" href="./assets/Main/oplata_files/pay.css">

    <script src="./assets/Main/oplata_files/jquery.min.js"></script>

    <script src="./assets/Main/oplata_files/axios.min.js"></script>

</head>


<body style="background: #f8f9fa">
<div class="preloader"><div class="loader"></div></div>

    <div id="payment">
        <section class="vh-100 py-5 py-xl-8 py-lg-7 py-md-6 py-sm-5 bg-transparent" style="padding-top: 3rem !important;">
            <div class="container position-relative zindex-100">
       
                <div class="row align-items-center mb-5">
                    <div class="col-sm-6 text-sm-right order-sm-2">
                        <h1 class="display-3 mb-0 text-black font-weight-bolder"><?=$_POST['price']?> ₽</h1>
                    </div>
                    <div class="col-sm-6 my-auto order-sm-1">
                        <h1 class="font-weight-bolder mb-0 text-black">Оплата товара: <?=$_POST['title']?></h1>
                        <p class="mb-0 text-black">Выберите предпочитаемый способ оплаты.</p>
                    </div>
                </div>
                <h4 class="font-weight-bold text-black">Электронные деньги</h4>
                <div class="row mb-5">
                    <div class="col-lg-4 col-md-6">
                        <a href="/qiwi.php?price=<?=$_POST['price']?>&nick=<?=$_POST['nick']?>" data-request="onBuy" data-request-flash="">
                            <div class="card mb-2 border-0 rounded-0 shadow-sm hover-scale-110">
                                <div class="card-body d-flex p-3" data-method="qiwi_kz">
                                    <div class="my-auto">
                                        <img src="./assets/Main/oplata_files/qiwi.png" class="img-fluid img-center" style="width: 48px">
                                    </div>
                                    <div class="my-auto ml-4">
                                        <h6 class="font-weight-bolder mb-1 text-black">Qiwi Кошелек (Рубли)</h6>
                                        <p class="small mb-0 text-uppercase text-black">Электронные деньги</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <a href="/qiwi.php?price=<?=$_POST['price']?>&nick=<?=$_POST['nick']?>" data-request="onBuy" data-request-flash="">
                            <div class="card mb-2 border-0 rounded-0 shadow-sm hover-scale-110">
                                <div class="card-body d-flex p-3" data-method="qiwi_kz">
                                    <div class="my-auto">
                                        <img src="./assets/Main/oplata_files/qiwi.png" class="img-fluid img-center" style="width: 48px">
                                    </div>
                                    <div class="my-auto ml-4">
                                        <h6 class="font-weight-bolder mb-1 text-black">Qiwi Кошелек (Тенге)</h6>
                                        <p class="small mb-0 text-uppercase text-black">Электронные деньги</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <a href="/anypay.php?price=<?=$_POST['price']?>&nick=<?=$_POST['nick']?>" data-request="onBuy" data-request-flash="">
                            <div class="card mb-2 border-0 rounded-0 shadow-sm hover-scale-110">
                                <div class="card-body d-flex p-3" data-method="yoomoney">
                                    <div class="my-auto">
                                        <img src="./assets/Main/oplata_files/umoney.svg" class="img-fluid img-center" style="width: 48px">
                                    </div>
                                    <div class="my-auto ml-4">
                                        <h6 class="font-weight-bolder mb-1 text-black">ЮMoney</h6>
                                        <p class="small mb-0 text-uppercase text-black">Электронные деньги</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                </div>
                <h4 class="font-weight-bold text-black">Безналичные</h4>
                <div class="row mb-5">
                    <div class="col-lg-4 col-md-6">
                        <a href="/qiwi.php?price=<?=$_POST['price']?>&nick=<?=$_POST['nick']?>" data-request="onBuy" data-request-flash="">
                            <div class="card mb-2 border-0 rounded-0 shadow-sm hover-scale-110">
                                <div class="card-body d-flex p-3" data-method="yoocard">
                                    <div class="my-auto">
                                        <img src="./assets/Main/oplata_files/card.svg" class="img-fluid img-center" style="width: 48px">
                                    </div>
                                    <div class="my-auto ml-4">
                                        <h5 class="font-weight-bolder mb-1 text-black">Банковская карта</h5>
                                      <p class="small mb-0 text-uppercase text-black">Безналичные</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>


                <h4 class="font-weight-bold text-black">Мобильный платеж</h4>
                <div class="row mb-5">
                    <div class="col-lg-4 col-md-6">
                        <a href="#" data-request="onBuy" data-request-flash="">
                            <div class="card mb-2 border-0 rounded-0 shadow-sm hover-scale-110 opacity-5">
                                <div class="card-body d-flex p-3" data-method="beeline;disabled">
                                    <div class="my-auto">
                                        <img src="./assets/Main/oplata_files/beeline.png" class="img-fluid img-center" style="width: 48px">
                                    </div>
                                    <div class="my-auto ml-4">
                                        <h5 class="font-weight-bolder mb-1 text-black">Билайн</h5>
                                        <p class="small mb-0 text-uppercase text-black">ВРЕМЕННО НЕ ДОСТУПНО</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <a href="#" data-request="onBuy" data-request-flash="">
                            <div class="card mb-2 border-0 rounded-0 shadow-sm hover-scale-110 opacity-5">
                                <div class="card-body d-flex p-3" data-method="tele2;disabled">
                                    <div class="my-auto">
                                        <img src="./assets/Main/oplata_files/tele2.png" class="img-fluid img-center" style="width: 48px">
                                    </div>
                                    <div class="my-auto ml-4">
                                        <h5 class="font-weight-bolder mb-1 text-black">Теле2</h5>
                                        <p class="small mb-0 text-uppercase text-black">ВРЕМЕННО НЕ ДОСТУПНО</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <a href="#" data-request="onBuy" data-request-flash="">
                            <div class="card mb-2 border-0 rounded-0 shadow-sm hover-scale-110">
                                <div class="card-body d-flex p-3" data-method="megafon;disabled">
                                    <div class="my-auto">
                                        <img src="./assets/Main/oplata_files/megafon.png" class="img-fluid img-center" style="width: 48px">
                                    </div>
                                    <div class="my-auto ml-4">
                                        <h5 class="font-weight-bolder mb-1 text-black">Мегафон</h5>
                                        <p class="small mb-0 text-uppercase text-black">Мобильный платеж</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <a href="#" data-request="onBuy" data-request-flash="">
                            <div class="card mb-2 border-0 rounded-0 shadow-sm hover-scale-110 opacity-5">
                                <div class="card-body d-flex p-3" data-method="mts;disabled">
                                    <div class="my-auto">
                                        <img src="./assets/Main/oplata_files/mts.png" class="img-fluid img-center" style="width: 48px">
                                    </div>
                                    <div class="my-auto ml-4">
                                        <h5 class="font-weight-bolder mb-1 text-black">МТС</h5>
                                        <p class="small mb-0 text-uppercase text-black">ВРЕМЕННО НЕ ДОСТУПНО</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                
                </div>
            </section></div>
        
    





<style>

.preloader {
    display: none;
    position: fixed;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    background: rgb(36 38 46 / 50%);
    z-index: 1001;
}

.loaded_hiding .preloader {
    transition: 0.3s opacity;
    opacity: 0;
}

.loader {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    box-shadow: 24px 0 0 6px #ffbe3d, -24px 0 0 6px #ffbe3d;
    position: relative;
    animation: spinner-xp626r 1s infinite;
    top: 50%;
    margin: -28px auto 0;
}

@keyframes spinner-xp626r {
   to {
      transform: rotate(360deg);
   }
}


</style>

<script>
        (function() {
            $('.card-body').click(function() {
                    const method = $(this).data('method');
                    if(!method.split(';')[1]){
                        document.querySelector('.preloader').style = `display: flex;`;
                        axios.post(`/qiwi.php`, `&price=<?=$_POST['price']?>&nick=<?=$_POST['nick']?>&`).then(function(e){
                            const data = JSON.parse(JSON.stringify(e.data));
                            window.location.href = data.link;
                        })
                    }
            })
        })();

    </script>



</body></html>