-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июл 20 2022 г., 16:20
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `holcvipr_123`
--

-- --------------------------------------------------------

--
-- Структура таблицы `live`
--
-- Создание: Июл 14 2022 г., 00:05
--

DROP TABLE IF EXISTS `live`;
CREATE TABLE `live` (
  `live_id` int(10) UNSIGNED NOT NULL,
  `live_nickname` varchar(50) NOT NULL DEFAULT '',
  `live_name` varchar(50) NOT NULL,
  `live_price` varchar(50) NOT NULL,
  `live_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `live`
--

INSERT INTO `live` (`live_id`, `live_nickname`, `live_name`, `live_price`, `live_img`) VALUES
(1, '1_DENK_1', 'HERO', '10', '/assets/Main/img/donate/hero.webp'),
(2, '1_DENK_1', 'FERK', '20', '/assets/Main/img/donate/ferk.webp'),
(3, '1_DENK_1', 'LIME', '55', '/assets/Main/img/donate/lime.webp'),
(4, '1_DENK_1', 'MINER', '75', '/assets/Main/img/donate/miner.webp'),
(5, '1_DENK_1', 'FIRE', '139', '/assets/Main/img/donate/fire.webp'),
(6, '1_DENK_1', 'GUARDIAN', '249', '/assets/Main/img/donate/guardian.webp'),
(7, '1_DENK_1', 'MERCHANT', '349', '/assets/Main/img/donate/merchant.webp'),
(8, '1_DENK_1', 'WELF', '500', '/assets/Main/img/donate/welf.webp');

CREATE TABLE `usertbl` (
`id` int(11) NOT NULL auto_increment,
`full_name` varchar(32) collate utf8_unicode_ci NOT NULL default '',
`email` varchar(32) collate utf8_unicode_ci NOT NULL default '',
`username` varchar(20) collate utf8_unicode_ci NOT NULL default '',
`password` varchar(32) collate utf8_unicode_ci NOT NULL default '',
PRIMARY KEY  (`id`),
UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `luckperms_actions`
--
-- Создание: Июл 12 2022 г., 17:53
--

DROP TABLE IF EXISTS `luckperms_actions`;
CREATE TABLE `luckperms_actions` (
  `id` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `actor_uuid` varchar(36) NOT NULL,
  `actor_name` varchar(100) NOT NULL,
  `type` char(1) NOT NULL,
  `acted_uuid` varchar(36) NOT NULL,
  `acted_name` varchar(36) NOT NULL,
  `action` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `luckperms_actions`
--

INSERT INTO `luckperms_actions` (`id`, `time`, `actor_uuid`, `actor_name`, `type`, `acted_uuid`, `acted_name`, `action`) VALUES
(1, 1623218773, '00000000-0000-0000-0000-000000000000', 'Console@grief', 'U', '6c93f232-c2a0-3f8f-8c52-431c2ae36ef3', 'notver12', 'parent set elder'),
(2, 1623218859, '00000000-0000-0000-0000-000000000000', 'Console@grief', 'U', '6c93f232-c2a0-3f8f-8c52-431c2ae36ef3', 'notver12', 'parent set elder');

-- --------------------------------------------------------

--
-- Структура таблицы `luckperms_groups`
--
-- Создание: Июл 12 2022 г., 17:53
--

DROP TABLE IF EXISTS `luckperms_groups`;
CREATE TABLE `luckperms_groups` (
  `name` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `luckperms_groups`
--

INSERT INTO `luckperms_groups` (`name`) VALUES
('admin'),
('default'),
('dejavu'),
('elder'),
('furry'),
('helper'),
('junior'),
('legend'),
('moder'),
('neon'),
('overlord'),
('s.moder'),
('silver'),
('youtube');

-- --------------------------------------------------------

--
-- Структура таблицы `luckperms_group_permissions`
--
-- Создание: Июл 12 2022 г., 17:53
--

DROP TABLE IF EXISTS `luckperms_group_permissions`;
CREATE TABLE `luckperms_group_permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(36) NOT NULL,
  `permission` varchar(200) NOT NULL,
  `value` tinyint(1) NOT NULL,
  `server` varchar(36) NOT NULL,
  `world` varchar(64) NOT NULL,
  `expiry` bigint(20) NOT NULL,
  `contexts` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `luckperms_group_permissions`
--

INSERT INTO `luckperms_group_permissions` (`id`, `name`, `permission`, `value`, `server`, `world`, `expiry`, `contexts`) VALUES
(1, 'youtube', 'cmi.kit.mega', 1, 'global', 'global', 0, '{}'),
(2, 'youtube', 'weight.17', 1, 'global', 'global', 0, '{}'),
(3, 'youtube', 'prefix.5.&f&lYOUTUBE&7 ', 1, 'global', 'global', 0, '{}'),
(4, 'youtube', 'cmi.kit.youtube', 1, 'global', 'global', 0, '{}'),
(5, 'youtube', 'litebans.group.youtube', 1, 'global', 'global', 0, '{}'),
(6, 'youtube', 'cmi.command.broadcast', 1, 'global', 'global', 0, '{}'),
(7, 'youtube', 'worldguard.region.flag.flags.entry.*', 1, 'global', 'global', 0, '{}'),
(8, 'youtube', 'suffix.5.&f', 1, 'global', 'global', 0, '{}'),
(9, 'youtube', 'group.furry', 1, 'global', 'global', 0, '{}'),
(10, 'youtube', 'antiafkpro.bypass', 1, 'global', 'global', 0, '{}'),
(11, 'youtube', 'cmi.command.sethome.999', 1, 'global', 'global', 0, '{}'),
(12, 'youtube', 'cmi.kit.furry', 0, 'global', 'global', 0, '{}'),
(13, 'helper', 'cmi.kit.helper', 1, 'global', 'global', 0, '{}'),
(14, 'helper', 'litebans.mute', 1, 'global', 'global', 0, '{}'),
(15, 'helper', 'litebans.kick', 1, 'global', 'global', 0, '{}'),
(16, 'helper', 'cmi.command.fly', 1, 'global', 'global', 0, '{}'),
(17, 'helper', 'essentials.gamemode.*', 1, 'duels', 'global', 0, '{}'),
(18, 'helper', 'prefix.5.&e&lHELPER &7', 1, 'global', 'global', 0, '{}'),
(19, 'helper', 'weight.18', 1, 'global', 'global', 0, '{}'),
(20, 'helper', 'litebans.unmute', 1, 'global', 'global', 0, '{}'),
(21, 'helper', 'cmi.kit.youtube', 0, 'global', 'global', 0, '{}'),
(22, 'helper', 'litebans.tempban', 1, 'global', 'global', 0, '{}'),
(23, 'helper', 'litebans.unban', 1, 'global', 'global', 0, '{}'),
(24, 'helper', 'cmi.kit.mega', 0, 'global', 'global', 0, '{}'),
(25, 'helper', 'matrix.notify', 1, 'global', 'global', 0, '{}'),
(26, 'helper', 'suffix.5.&e', 1, 'global', 'global', 0, '{}'),
(27, 'helper', 'meta.default.false', 1, 'global', 'global', 0, '{}'),
(28, 'helper', 'essentials.tp', 1, 'duels', 'global', 0, '{}'),
(29, 'helper', 'group.youtube', 1, 'global', 'global', 0, '{}'),
(30, 'helper', 'cmi.command.tp', 1, 'global', 'global', 0, '{}'),
(31, 'helper', 'litebans.group.helper', 1, 'global', 'global', 0, '{}'),
(32, 'helper', 'cmi.command.god', 1, 'global', 'global', 0, '{}'),
(33, 'helper', 'cmi.command.vanish', 1, 'global', 'global', 0, '{}'),
(34, 'helper', 'litebans.ban', 1, 'global', 'global', 0, '{}'),
(35, 'elder', 'cmi.command.feed', 1, 'global', 'global', 0, '{}'),
(36, 'elder', 'cmi.command.heal', 1, 'global', 'global', 0, '{}'),
(37, 'elder', 'cmi.command.sethome.4', 1, 'global', 'global', 0, '{}'),
(38, 'elder', 'cmi.kit.elder', 1, 'global', 'global', 0, '{}'),
(39, 'elder', 'prefix.5.&2ELDER &7', 1, 'global', 'global', 0, '{}'),
(40, 'elder', 'suffix.5.&2', 1, 'global', 'global', 0, '{}'),
(41, 'elder', 'group.silver', 1, 'global', 'global', 0, '{}'),
(42, 'elder', 'meta.default.false', 1, 'global', 'global', 0, '{}'),
(43, 'elder', 'cmi.kit.silver', 0, 'global', 'global', 0, '{}'),
(44, 'elder', 'weight.3', 1, 'global', 'global', 0, '{}'),
(45, 'elder', 'crazyauctions.sell.6', 1, 'global', 'global', 0, '{}'),
(46, 'legend', 'cmi.kit.junior', 0, 'global', 'global', 0, '{}'),
(47, 'legend', 'prefix.5.&d&lLEGEND &7', 1, 'global', 'global', 0, '{}'),
(48, 'legend', 'suffix.5.&d', 1, 'global', 'global', 0, '{}'),
(49, 'legend', 'group.junior', 1, 'global', 'global', 0, '{}'),
(50, 'legend', 'crazyauctions.sell.10', 1, 'global', 'global', 0, '{}'),
(51, 'legend', 'meta.default.false', 1, 'global', 'global', 0, '{}'),
(52, 'legend', 'cmi.command.socialspy', 1, 'global', 'global', 0, '{}'),
(53, 'legend', 'weight.5', 1, 'global', 'global', 0, '{}'),
(54, 'legend', 'cmi.command.sethome.8', 1, 'global', 'global', 0, '{}'),
(55, 'legend', 'cmi.kit.legend', 1, 'global', 'global', 0, '{}'),
(56, 'legend', 'cmi.command.inv', 1, 'global', 'global', 0, '{}'),
(57, 'neon', 'prefix.5.&6&lNEON&7 ', 1, 'global', 'global', 0, '{}'),
(58, 'neon', 'weight.7', 1, 'global', 'global', 0, '{}'),
(59, 'neon', 'cmi.command.sethome.20', 1, 'global', 'global', 0, '{}'),
(60, 'neon', 'cmi.kit.neon', 1, 'global', 'global', 0, '{}'),
(61, 'neon', 'litebans.tempmute', 1, 'global', 'global', 0, '{}'),
(62, 'neon', 'cmi.command.weather.*', 1, 'global', 'global', 0, '{}'),
(63, 'neon', 'cmi.command.nick', 1, 'global', 'global', 0, '{}'),
(64, 'neon', 'litebans.group.neon', 1, 'global', 'global', 0, '{}'),
(65, 'neon', 'crazyauctions.sell.18', 1, 'global', 'global', 0, '{}'),
(66, 'neon', 'suffix.5.&6', 1, 'global', 'global', 0, '{}'),
(67, 'neon', 'cmi.kit.overlord', 0, 'global', 'global', 0, '{}'),
(68, 'neon', 'cmi.command.weather', 1, 'global', 'global', 0, '{}'),
(69, 'neon', 'cmi.command.weather.sun', 1, 'global', 'global', 0, '{}'),
(70, 'neon', 'group.overlord', 1, 'global', 'global', 0, '{}'),
(71, 'neon', 'cmi.command.weather.rain', 1, 'global', 'global', 0, '{}'),
(72, 'furry', 'cmi.kit.mega', 1, 'global', 'global', 0, '{}'),
(73, 'furry', 'weight.8', 1, 'global', 'global', 0, '{}'),
(74, 'furry', 'prefix.5.&5&lFURRY&7 ', 1, 'global', 'global', 0, '{}'),
(75, 'furry', 'cmi.kit.neon', 0, 'global', 'global', 0, '{}'),
(76, 'furry', 'cmi.kit.furry', 1, 'global', 'global', 0, '{}'),
(77, 'furry', 'crazyauctions.sell.28', 1, 'global', 'global', 0, '{}'),
(78, 'furry', 'group.neon', 1, 'global', 'global', 0, '{}'),
(79, 'furry', 'litebans.unmute', 1, 'global', 'global', 0, '{}'),
(80, 'furry', 'cmi.command.sethome.999', 1, 'global', 'global', 0, '{}'),
(81, 'furry', 'suffix.5.&5', 1, 'global', 'global', 0, '{}'),
(82, 'furry', 'litebans.tempban', 1, 'global', 'global', 0, '{}'),
(83, 'admin', 'suffix.5.&c', 1, 'global', 'global', 0, '{}'),
(84, 'admin', 'weight.99', 1, 'global', 'global', 0, '{}'),
(85, 'admin', 'group.s.moder', 1, 'global', 'global', 0, '{}'),
(86, 'admin', '*', 1, 'global', 'global', 0, '{}'),
(87, 'admin', 'meta.default.false', 1, 'global', 'global', 0, '{}'),
(88, 'admin', 'prefix.5.&c&lADMIN &7', 1, 'global', 'global', 0, '{}'),
(89, 'silver', 'group.default', 1, 'global', 'global', 0, '{}'),
(90, 'silver', 'prefix.5.&7SILVER &7', 1, 'global', 'global', 0, '{}'),
(91, 'silver', 'weight.2', 1, 'global', 'global', 0, '{}'),
(92, 'silver', 'cmi.inventoryhat', 1, 'global', 'global', 0, '{}'),
(93, 'silver', 'cmi.command.hat', 1, 'global', 'global', 0, '{}'),
(94, 'silver', 'crazyauctions.sell.4', 1, 'global', 'global', 0, '{}'),
(95, 'silver', 'suffix.5.&7', 1, 'global', 'global', 0, '{}'),
(96, 'silver', 'cmi.command.ender', 1, 'grief', 'global', 0, '{}'),
(97, 'silver', 'meta.default.false', 1, 'global', 'global', 0, '{}'),
(98, 'silver', 'cmi.command.workbench', 1, 'global', 'global', 0, '{}'),
(99, 'silver', 'cmi.command.sethome.2', 1, 'global', 'global', 0, '{}'),
(100, 'silver', 'cmi.kit.silver', 1, 'global', 'global', 0, '{}'),
(101, 'silver', 'cmi.kit.default', 0, 'global', 'global', 0, '{}'),
(102, 's.moder', '*', 1, 'global', 'global', 0, '{}'),
(103, 's.moder', 'meta.default.false', 1, 'global', 'global', 0, '{}'),
(104, 's.moder', 'group.moder', 1, 'global', 'global', 0, '{}'),
(105, 's.moder', 'prefix.5.&4&lS\\.MODER &7', 1, 'global', 'global', 0, '{}'),
(106, 's.moder', 'weight.20', 1, 'global', 'global', 0, '{}'),
(107, 's.moder', 'suffix.5.&4', 1, 'global', 'global', 0, '{}'),
(108, 'junior', 'cmi.kit.junior', 1, 'global', 'global', 0, '{}'),
(109, 'junior', 'lunex.near', 1, 'global', 'global', 0, '{}'),
(110, 'junior', 'cmi.command.near', 1, 'global', 'global', 0, '{}'),
(111, 'junior', 'strikepractice.premiumqueue', 1, 'global', 'global', 0, '{}'),
(112, 'junior', 'weight.4', 1, 'global', 'global', 0, '{}'),
(113, 'junior', 'group.elder', 1, 'global', 'global', 0, '{}'),
(114, 'junior', 'cmi.kit.elder', 0, 'global', 'global', 0, '{}'),
(115, 'junior', 'crazyauctions.sell.8', 1, 'global', 'global', 0, '{}'),
(116, 'junior', 'prefix.5.&6JUNIOR &7', 1, 'global', 'global', 0, '{}'),
(117, 'junior', 'cmi.command.sethome.6', 1, 'global', 'global', 0, '{}'),
(118, 'junior', 'suffix.5.&6', 1, 'global', 'global', 0, '{}'),
(119, 'junior', 'meta.default.false', 1, 'global', 'global', 0, '{}'),
(120, 'junior', 'cmi.command.ptime', 1, 'global', 'global', 0, '{}'),
(121, 'junior', 'ukrainertp.near', 1, 'global', 'global', 0, '{}'),
(122, 'moder', 'litebans.group.moder', 1, 'global', 'global', 0, '{}'),
(123, 'moder', 'minecraft.command.say', 1, 'global', 'global', 0, '{}'),
(124, 'moder', 'suffix.5.&2', 1, 'global', 'global', 0, '{}'),
(125, 'moder', 'cmi.command.*', 1, 'global', 'global', 0, '{}'),
(126, 'moder', 'worldedit.*', 0, 'global', 'global', 0, '{}'),
(127, 'moder', 'worldguard.*', 1, 'global', 'global', 0, '{}'),
(128, 'moder', 'matrix.notify', 1, 'global', 'global', 0, '{}'),
(129, 'moder', 'litebans.unbanip', 1, 'global', 'global', 0, '{}'),
(130, 'moder', 'cmi.*', 1, 'global', 'global', 0, '{}'),
(131, 'moder', 'weight.19', 1, 'global', 'global', 0, '{}'),
(132, 'moder', 'meta.default.false', 1, 'global', 'global', 0, '{}'),
(133, 'moder', 'prefix.5.&2&lMODERATOR &7', 1, 'global', 'global', 0, '{}'),
(134, 'moder', 'cmi.command.sound', 0, 'global', 'global', 0, '{}'),
(135, 'moder', 'cmi.seevanished', 1, 'global', 'global', 0, '{}'),
(136, 'moder', 'litebans.banip', 1, 'global', 'global', 0, '{}'),
(137, 'moder', 'matrix.bypass', 1, 'global', 'global', 0, '{}'),
(138, 'moder', 'group.helper', 1, 'global', 'global', 0, '{}'),
(139, 'default', 'worldguard.region.info.member.*', 1, 'grief', 'global', 0, '{}'),
(140, 'default', 'strikepractice.playback', 0, 'duels', 'global', 0, '{}'),
(141, 'default', 'betterrtp.player', 0, 'global', 'global', 0, '{}'),
(142, 'default', 'deluxemenus.open', 1, 'global', 'global', 0, '{}'),
(143, 'default', 'litebans.notify.muted', 1, 'global', 'global', 0, '{}'),
(144, 'default', 'cmi.command.money', 1, 'grief', 'global', 0, '{}'),
(145, 'default', 'worldguard.region.addowner.own.*', 1, 'grief', 'global', 0, '{}'),
(146, 'default', 'strikepractice.partyplayback', 0, 'duels', 'global', 0, '{}'),
(147, 'default', 'strikepractice.hostevent', 0, 'duels', 'global', 0, '{}'),
(148, 'default', 'silkspawners.info', 1, 'global', 'global', 0, '{}'),
(149, 'default', 'litebans.notify.broadcast', 1, 'global', 'global', 0, '{}'),
(150, 'default', 'silkspawners.viewtype', 1, 'global', 'global', 0, '{}'),
(151, 'default', 'cmi.command.msg', 1, 'grief', 'global', 0, '{}'),
(152, 'default', 'cmi.command.sethome.1', 1, 'grief', 'global', 0, '{}'),
(153, 'default', 'strikepractice.juggernaut.command', 0, 'duels', 'global', 0, '{}'),
(154, 'default', 'strikepractice.customkit', 0, 'duels', 'global', 0, '{}'),
(155, 'default', 'chatty.chat.local', 1, 'global', 'global', 0, '{}'),
(156, 'default', 'cmi.command.pay', 1, 'grief', 'global', 0, '{}'),
(157, 'default', 'worldguard.region.info.*', 1, 'grief', 'global', 0, '{}'),
(158, 'default', 'crazyauctions.sell', 1, 'global', 'global', 0, '{}'),
(159, 'default', 'cmi.command.tpa', 1, 'grief', 'global', 0, '{}'),
(160, 'default', 'bukkit.command.help', 0, 'global', 'global', 0, '{}'),
(161, 'default', 'cmi.command.tpdeny', 1, 'grief', 'global', 0, '{}'),
(162, 'default', 'cmi.command.baltop', 1, 'grief', 'global', 0, '{}'),
(163, 'default', 'cmi.command.sethome', 1, 'grief', 'global', 0, '{}'),
(164, 'default', 'worldedit.selection.expand', 1, 'grief', 'global', 0, '{}'),
(165, 'default', 'betterrtp.use', 1, 'global', 'global', 0, '{}'),
(166, 'default', 'minecraft.command.say', 0, 'global', 'global', 0, '{}'),
(167, 'default', 'owlsmines.getmoney', 1, 'global', 'global', 0, '{}'),
(168, 'default', 'suffix.5.&7', 1, 'global', 'global', 0, '{}'),
(169, 'default', 'betterrtp.rtp', 1, 'grief', 'global', 0, '{}'),
(170, 'default', 'liteplaytimerewards.rewards', 1, 'global', 'global', 0, '{}'),
(171, 'default', 'clans.user', 1, 'grief', 'global', 0, '{}'),
(172, 'default', 'worldedit.wand', 1, 'grief', 'global', 0, '{}'),
(173, 'default', 'chatty.notification.chat.default', 1, 'global', 'global', 0, '{}'),
(174, 'default', 'crazyauctions.sell.2', 1, 'global', 'global', 0, '{}'),
(175, 'default', 'rosecutter.getmoney', 1, 'global', 'global', 0, '{}'),
(176, 'default', 'betterrtp.player', 1, 'grief', 'global', 0, '{}'),
(177, 'default', 'crazycrates.open', 1, 'global', 'global', 0, '{}'),
(178, 'default', 'worldguard.region.addmember.own.*', 1, 'grief', 'global', 0, '{}'),
(179, 'default', 'cmi.command.spawn', 1, 'grief', 'global', 0, '{}'),
(180, 'default', 'silkspawners.place.*', 1, 'grief', 'global', 0, '{}'),
(181, 'default', 'worldguard.region.wand', 1, 'grief', 'global', 0, '{}'),
(182, 'default', 'worldguard.region.info.own.*', 1, 'grief', 'global', 0, '{}'),
(183, 'default', 'cmi.command.homes', 1, 'grief', 'global', 0, '{}'),
(184, 'default', 'litebans.json.hover_text', 1, 'global', 'global', 0, '{}'),
(185, 'default', 'worldedit.selection.*', 1, 'grief', 'global', 0, '{}'),
(186, 'default', 'owlscutter.getmoney', 1, 'global', 'global', 0, '{}'),
(187, 'default', 'modifyworld.*', 1, 'grief', 'global', 0, '{}'),
(188, 'default', 'cmi.command.balance', 1, 'grief', 'global', 0, '{}'),
(189, 'default', 'strikepractice.brackets.command', 0, 'duels', 'global', 0, '{}'),
(190, 'default', 'worldguard.region.flag.regions.own.*', 1, 'grief', 'global', 0, '{}'),
(191, 'default', 'cmi.kit.default', 1, 'grief', 'global', 0, '{}'),
(192, 'default', 'quests.command', 1, 'global', 'global', 0, '{}'),
(193, 'default', 'betterrtp.world.world', 1, 'global', 'global', 0, '{}'),
(194, 'default', 'cmi.command.warp', 1, 'grief', 'global', 0, '{}'),
(195, 'default', 'strikepractice.playersettings', 0, 'duels', 'global', 0, '{}'),
(196, 'default', 'serversigns.use.*', 1, 'grief', 'global', 0, '{}'),
(197, 'default', 'cmi.command.call', 1, 'grief', 'global', 0, '{}'),
(198, 'default', 'strikepractice.duel', 0, 'duels', 'global', 0, '{}'),
(199, 'default', 'prefix.5.&7', 1, 'global', 'global', 0, '{}'),
(200, 'default', 'minecraft.command.tell', 0, 'global', 'global', 0, '{}'),
(201, 'default', 'advancedsmelting.smelt', 1, 'grief', 'global', 0, '{}'),
(202, 'default', 'bukkit.broadcast.user', 0, 'global', 'global', 0, '{}'),
(203, 'default', 'jetsantiafkpro.player.afk', 1, 'global', 'global', 0, '{}'),
(204, 'default', 'rosemines.getmoney', 1, 'global', 'global', 0, '{}'),
(205, 'default', 'bukkit.broadcast.admin', 0, 'global', 'global', 0, '{}'),
(206, 'default', 'meta.default.true', 1, 'global', 'global', 0, '{}'),
(207, 'default', 'cmi.command.removehome', 1, 'grief', 'global', 0, '{}'),
(208, 'default', 'strikepractice.language', 0, 'duels', 'global', 0, '{}'),
(209, 'default', 'chatty.command.reply', 1, 'global', 'global', 0, '{}'),
(210, 'default', 'minecraft.command.tellraw', 0, 'global', 'global', 0, '{}'),
(211, 'default', 'worldguard.region.claim', 1, 'grief', 'global', 0, '{}'),
(212, 'default', 'minecraft.command.me', 0, 'global', 'global', 0, '{}'),
(213, 'default', 'chatty.chat.global', 1, 'global', 'global', 0, '{}'),
(214, 'default', 'jetsantiafkpro.player.top', 1, 'global', 'global', 0, '{}'),
(215, 'default', 'strikepractice.botduel', 0, 'duels', 'global', 0, '{}'),
(216, 'default', 'chatty.chat.local.see', 1, 'global', 'global', 0, '{}'),
(217, 'default', 'worldguard.region.removemember.own.*', 1, 'grief', 'global', 0, '{}'),
(218, 'default', 'cmi.command.home', 1, 'grief', 'global', 0, '{}'),
(219, 'default', 'worldguard.region.list.own', 1, 'grief', 'global', 0, '{}'),
(220, 'default', 'worldguard.region.remove.own.*', 1, 'grief', 'global', 0, '{}'),
(221, 'default', 'bukkit.command.paper', 0, 'global', 'global', 0, '{}'),
(222, 'default', 'worldguard.region.removeowner.own.*', 1, 'grief', 'global', 0, '{}'),
(223, 'default', 'chatty.command.msg', 1, 'global', 'global', 0, '{}'),
(224, 'default', 'crazyauctions.access', 1, 'global', 'global', 0, '{}'),
(225, 'default', 'weight.1', 1, 'global', 'global', 0, '{}'),
(226, 'default', 'cmi.command.tpaccept', 1, 'grief', 'global', 0, '{}'),
(227, 'default', 'cmi.kit.*.preview', 1, 'grief', 'global', 0, '{}'),
(228, 'default', 'strikepractice.koth.command', 0, 'duels', 'global', 0, '{}'),
(229, 'default', 'strikepractice.lms.command', 0, 'duels', 'global', 0, '{}'),
(230, 'overlord', 'crazyauctions.sell.12', 1, 'global', 'global', 0, '{}'),
(231, 'overlord', 'cmi.command.sethome.12', 1, 'global', 'global', 0, '{}'),
(232, 'overlord', 'cmi.kit.legend', 0, 'global', 'global', 0, '{}'),
(233, 'overlord', 'litebans.kick', 1, 'global', 'global', 0, '{}'),
(234, 'overlord', 'prefix.5.&4&lOVERLORD &7', 1, 'global', 'global', 0, '{}'),
(235, 'overlord', 'cmi.command.time', 1, 'global', 'global', 0, '{}'),
(236, 'overlord', 'cmi.command.time.edit', 1, 'global', 'global', 0, '{}'),
(237, 'overlord', 'weight.6', 1, 'global', 'global', 0, '{}'),
(238, 'overlord', 'meta.default.false', 1, 'global', 'global', 0, '{}'),
(239, 'overlord', 'suffix.5.&4', 1, 'global', 'global', 0, '{}'),
(240, 'overlord', 'group.legend', 1, 'global', 'global', 0, '{}'),
(241, 'overlord', 'cmi.kit.overlord', 1, 'global', 'global', 0, '{}'),
(242, 'dejavu', 'cmi.kit.mega', 0, 'global', 'global', 0, '{}'),
(243, 'dejavu', 'crazyauctions.sell.30', 1, 'global', 'global', 0, '{}'),
(244, 'dejavu', 'weight.9', 1, 'global', 'global', 0, '{}'),
(245, 'dejavu', 'cmi.command.thor', 1, 'global', 'global', 0, '{}'),
(246, 'dejavu', 'cmi.kit.omega', 1, 'global', 'global', 0, '{}'),
(247, 'dejavu', 'cmi.kit.dejavu', 1, 'global', 'global', 0, '{}'),
(248, 'dejavu', 'suffix.5.&3', 1, 'global', 'global', 0, '{}'),
(249, 'dejavu', 'group.furry', 1, 'global', 'global', 0, '{}'),
(250, 'dejavu', 'prefix.5.&3&l&oDEJAVU&7 ', 1, 'global', 'global', 0, '{}'),
(251, 'dejavu', 'cmi.kit.furry', 0, 'global', 'global', 0, '{}'),
(252, 'dejavu', 'litebans.unban', 1, 'global', 'global', 0, '{}');

-- --------------------------------------------------------

--
-- Структура таблицы `luckperms_messenger`
--
-- Создание: Июл 12 2022 г., 17:53
--

DROP TABLE IF EXISTS `luckperms_messenger`;
CREATE TABLE `luckperms_messenger` (
  `id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `luckperms_players`
--
-- Создание: Июл 12 2022 г., 17:53
--

DROP TABLE IF EXISTS `luckperms_players`;
CREATE TABLE `luckperms_players` (
  `uuid` varchar(36) NOT NULL,
  `username` varchar(16) NOT NULL,
  `primary_group` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `luckperms_players`
--

INSERT INTO `luckperms_players` (`uuid`, `username`, `primary_group`) VALUES
('6c93f232-c2a0-3f8f-8c52-431c2ae36ef3', 'notver12', 'elder');

-- --------------------------------------------------------

--
-- Структура таблицы `luckperms_tracks`
--
-- Создание: Июл 12 2022 г., 17:53
--

DROP TABLE IF EXISTS `luckperms_tracks`;
CREATE TABLE `luckperms_tracks` (
  `name` varchar(36) NOT NULL,
  `groups` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `luckperms_user_permissions`
--
-- Создание: Июл 12 2022 г., 17:53
--

DROP TABLE IF EXISTS `luckperms_user_permissions`;
CREATE TABLE `luckperms_user_permissions` (
  `id` int(11) NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `permission` varchar(200) NOT NULL,
  `value` tinyint(1) NOT NULL,
  `server` varchar(36) NOT NULL,
  `world` varchar(64) NOT NULL,
  `expiry` bigint(20) NOT NULL,
  `contexts` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `luckperms_user_permissions`
--

INSERT INTO `luckperms_user_permissions` (`id`, `uuid`, `permission`, `value`, `server`, `world`, `expiry`, `contexts`) VALUES
(3, '6c93f232-c2a0-3f8f-8c52-431c2ae36ef3', 'group.elder', 1, 'global', 'global', 0, '{}');

-- --------------------------------------------------------

--
-- Структура таблицы `promocode`
--
-- Создание: Июл 12 2022 г., 17:53
--

DROP TABLE IF EXISTS `promocode`;
CREATE TABLE `promocode` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `sale` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `purchases`
--
-- Создание: Июл 12 2022 г., 17:53
--

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `item` varchar(255) DEFAULT NULL,
  `title` varchar(50) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `purchases`
--

INSERT INTO `purchases` (`id`, `username`, `item`, `title`, `amount`, `image`) VALUES
(1, 'babykkrr_', 'eternal', 'ЭТЕРНАЛ', NULL, 'assets/donate/этернал.png'),
(2, 'Feltron', 'sigma', 'СИГМА', NULL, 'assets/donate/сигма.png'),
(3, 'DelayGrief', 'beta', 'БЕТА', NULL, 'assets/donate/бета.png'),
(4, 'belyashik3d', 'alpha', 'АЛЬФА', NULL, 'assets/donate/альфа.png'),
(5, 'itss_', 'eternal', 'ЭТЕРНАЛ', NULL, 'assets/donate/этернал.png'),
(6, 'sally007', 'delta', 'ДЕЛЬТА', NULL, 'assets/donate/дельта.png');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `luckperms_actions`
--
ALTER TABLE `luckperms_actions`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `luckperms_groups`
--
ALTER TABLE `luckperms_groups`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `luckperms_group_permissions`
--
ALTER TABLE `luckperms_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `luckperms_group_permissions_name` (`name`);

--
-- Индексы таблицы `luckperms_messenger`
--
ALTER TABLE `luckperms_messenger`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `luckperms_players`
--
ALTER TABLE `luckperms_players`
  ADD PRIMARY KEY (`uuid`),
  ADD KEY `luckperms_players_username` (`username`);

--
-- Индексы таблицы `luckperms_tracks`
--
ALTER TABLE `luckperms_tracks`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `luckperms_user_permissions`
--
ALTER TABLE `luckperms_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `luckperms_user_permissions_uuid` (`uuid`);

--
-- Индексы таблицы `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `luckperms_actions`
--
ALTER TABLE `luckperms_actions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `luckperms_group_permissions`
--
ALTER TABLE `luckperms_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=253;

--
-- AUTO_INCREMENT для таблицы `luckperms_messenger`
--
ALTER TABLE `luckperms_messenger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `luckperms_user_permissions`
--
ALTER TABLE `luckperms_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
